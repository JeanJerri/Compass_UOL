class TMDbException(Exception):
    pass
